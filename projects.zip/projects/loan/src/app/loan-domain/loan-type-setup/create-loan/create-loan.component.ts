import { Component } from '@angular/core';

@Component({
  selector: 'app-create-loan',
  standalone: true,
  imports: [],
  templateUrl: './create-loan.component.html',
  styleUrl: './create-loan.component.css'
})
export class CreateLoanComponent {

}
