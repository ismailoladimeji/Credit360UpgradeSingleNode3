import { Component } from '@angular/core';

@Component({
  selector: 'app-shell-layout',
  standalone: true,
  imports: [],
  templateUrl: './shell-layout.component.html',
  styleUrl: './shell-layout.component.scss'
})
export class ShellLayoutComponent {

}
