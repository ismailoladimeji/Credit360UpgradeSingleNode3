import { Component, ViewEncapsulation } from '@angular/core';
import { MaterialModule } from '../../material.module';

import { AppBlogComponent } from '../../components/apps-blog/apps-blog.component';
import { AppSalesOverviewComponent } from '../../components/sales-overview/sales-overview.component';
import { AppDailyActivitiesComponent } from '../../components/daily-activities/daily-activities.component';
import { AppProductPerformanceComponent } from '../../components/product-performance/product-performance.component';




@Component({
  selector: 'app-starter',
  imports: [
    MaterialModule,
    AppBlogComponent,
    AppSalesOverviewComponent,
    AppDailyActivitiesComponent,
    AppProductPerformanceComponent,

  ],
  standalone:true,
  templateUrl: './starter.component.html',
  encapsulation: ViewEncapsulation.None,
})
export class StarterComponent { }