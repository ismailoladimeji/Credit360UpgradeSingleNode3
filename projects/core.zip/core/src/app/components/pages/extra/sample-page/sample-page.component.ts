import { Component } from '@angular/core';
import { MaterialModule } from 'projects/core/src/app/material.module';


@Component({
  selector: 'app-sample-page',
  imports: [MaterialModule],
    standalone:true,
  templateUrl: './sample-page.component.html',
})

export class AppSamplePageComponent { }
