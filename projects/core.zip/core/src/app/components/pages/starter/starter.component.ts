import { Component, ViewEncapsulation } from '@angular/core';


import { MaterialModule } from '../../../material.module';
import { AppSalesOverviewComponent } from '../../sales-overview/sales-overview.component';
import { AppDailyActivitiesComponent } from '../../daily-activities/daily-activities.component';
import { AppProductPerformanceComponent } from '../../product-performance/product-performance.component';
import { AppBlogComponent } from '../../apps-blog/apps-blog.component';



@Component({
  selector: 'app-starter',
  imports: [
    MaterialModule,
    AppSalesOverviewComponent,
    AppDailyActivitiesComponent,
    AppProductPerformanceComponent,
    AppBlogComponent
  ],
  standalone:true,
  templateUrl: './starter.component.html',
  encapsulation: ViewEncapsulation.None,
})
export class StarterComponent { }