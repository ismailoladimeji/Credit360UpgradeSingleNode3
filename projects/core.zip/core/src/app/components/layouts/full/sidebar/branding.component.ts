import { Component } from '@angular/core';
import { CoreService } from 'projects/core/src/app/services/core.service';


@Component({
  selector: 'app-branding',
  imports: [],
  standalone:true,
  template: `
    <a href="/" class="logodark">
      <img
        src="./assets/images/logos/dark-logo.svg"
        class="align-middle m-2"
        alt="logo"
      />
    </a>
  `,
})
export class BrandingComponent {
  options = this.settings.getOptions();
  constructor(private settings: CoreService) {}
}
