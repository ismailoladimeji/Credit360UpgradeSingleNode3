import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { routes2 } from './app.routes';

const routes: Routes = [...routes2];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
