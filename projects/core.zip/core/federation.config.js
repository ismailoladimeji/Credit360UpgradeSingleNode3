const { withNativeFederation, shareAll } = require('@angular-architects/native-federation/config');

module.exports = withNativeFederation({

  name: 'core',

  exposes: {
    './Module': './projects/core/src/app/app.module.ts',
  },

  // shared: {
  //   ...shareAll({ singleton: true, strictVersion: true, requiredVersion: 'auto' }),
  // },
shared: {
  '@angular/core': { singleton: true, strictVersion: true },
  '@angular/common': { singleton: true, strictVersion: true},
  '@angular/common/http': { singleton: true, strictVersion: true},

  '@angular/forms': { singleton: true, strictVersion: true },
  '@angular/router': { singleton: true, strictVersion: true,},
  
  '@angular/animations': { singleton: true, strictVersion: true },
  '@angular/animations/browser': { singleton: true, strictVersion: true },
  

  '@angular/platform-browser': { singleton: true, strictVersion: true },
  '@angular/platform-browser/animations': { singleton: true, strictVersion: true },
  '@angular/platform-browser-dynamic': { singleton: true, strictVersion: true },
   '@angular/platform-browser/animations/async' : { singleton: true, strictVersion: true },

  '@angular/core/primitives/signals': { singleton: true, strictVersion: true },
  '@angular/core/primitives/di': { singleton: true, strictVersion: true },
  

  'rxjs': { singleton: true, strictVersion: true },
  'rxjs/operators': { singleton: true, strictVersion: true },
  rxjs: { singleton: true, strictVersion: true },
  'zone.js': { singleton: true, strictVersion: true },
},
  skip: [
    'rxjs/ajax',
    'rxjs/fetch',
    'rxjs/testing',
    'rxjs/webSocket',
    // Add further packages you don't need at runtime
  ],

  // Please read our FAQ about sharing libs:
  // https://shorturl.at/jmzH0

  features: {
    // New feature for more performance and avoiding
    // issues with node libs. Comment this out to
    // get the traditional behavior:
    ignoreUnusedDeps: true
  }
  
});
